# PayProof

Every payment. Proven.

PayProof is an MVP for transparent salary payment tracking for employees and small local businesses.

## Project structure

- `index.html` — application interface and page structure
- `css/style.css` — complete UI styling
- `js/payments.js` — payment recording, payment history, delays and dashboard analytics
- `js/solana.js` — Solana Devnet demo event preparation
- `js/phantom.js` — Phantom wallet connection/disconnection and account events
- `js/app.js` — application initialization

## MVP functionality

- Record salary payments in SOL
- Track payment history
- Track late payments
- Show payment statistics
- Show a critical warning after the third delay
- Payment analytics
- Accounting wallet dashboard
- Phantom wallet connection
- Solana Devnet demo event generation

## Important

The current Solana blockchain action is a demo/event preparation flow. Real on-chain payment recording is listed as future development in the MVP.
