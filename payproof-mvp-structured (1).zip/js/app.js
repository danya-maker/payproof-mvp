document.addEventListener("DOMContentLoaded", () => {
  updateAnalytics();
});
