const SOL_TO_KZT = 138000;

let paymentCount = 3;
let delayCount = 2;
let onTimeCount = 1;
let totalSol = 6.54;

function toast(text){
  const t = document.getElementById("toast");
  t.textContent = text;
  t.classList.add("show");
  setTimeout(() => {
    t.classList.remove("show");
  },2500);
}

function formatKzt(value){
  return "₸" + Math.round(value).toLocaleString("en-US");
}

function updateAnalytics(){
  const totalKzt = totalSol * SOL_TO_KZT;

  document.getElementById("totalPayroll").textContent =
    totalSol.toFixed(2) + " SOL";

  document.getElementById("totalPayrollKzt").textContent =
    "≈ " + formatKzt(totalKzt);

  document.getElementById("count").textContent = paymentCount;
  document.getElementById("onTime").textContent = onTimeCount;
  document.getElementById("delays").textContent = delayCount;
  document.getElementById("walletEvents").textContent = paymentCount;
  document.getElementById("walletDelays").textContent = delayCount;
}

function recordPayment(){
  const amount = Number(document.getElementById("amount").value);
  const late = document.getElementById("late").value;
  const employee =
    document.getElementById("employeeName").value.trim() || "Employee";

  if(!amount || amount <= 0){
    toast("Enter a payment amount in SOL.");
    return;
  }

  if(late === ""){
    toast("Enter the number of days late.");
    return;
  }

  const daysLate = Number(late);

  paymentCount++;
  totalSol += amount;

  if(daysLate > 0){
    delayCount++;
  }else{
    onTimeCount++;
  }

  const row = document.createElement("div");
  row.className = "payment";

  const date = new Date().toLocaleDateString("en-GB",{
    day:"2-digit",
    month:"short",
    year:"numeric"
  });

  row.innerHTML = `
    <span>${date}</span>
    <span>${amount.toFixed(2)} SOL</span>
    <span class="${daysLate > 0 ? "delayed" : "paid"}">
      ${daysLate > 0 ? daysLate + " days late" : "✓ On time"}
    </span>
    <span class="chain">Blockchain ready</span>
  `;

  document.getElementById("history").prepend(row);
  updateAnalytics();

  const warning = document.getElementById("warning");

  if(delayCount >= 3){
    warning.classList.add("critical");
    warning.innerHTML = `
      <strong>⚠ Critical payment warning:</strong>
      ${delayCount} payment delays have been recorded.
      Accounting attention is required.
    `;
  }else{
    warning.classList.remove("critical");
    warning.innerHTML = `
      <strong>⚠ Payment warning:</strong>
      ${delayCount} payment delays are currently recorded.
      A critical warning appears after the third delay.
    `;
  }

  document.getElementById("amount").value = "";
  document.getElementById("late").value = "";
  document.getElementById("employeeName").value = "";

  toast("✓ Payment for " + employee + " recorded.");
}
