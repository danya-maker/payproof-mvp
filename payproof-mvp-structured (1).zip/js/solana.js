function solana(){
  const id =
    "PAYPROOF-" +
    Date.now().toString(36).toUpperCase();

  document.getElementById("eventId").textContent =
    "Solana Devnet · Demo Event ID: " + id;

  document.getElementById("event").classList.add("show");

  toast("✓ Blockchain event prepared.");
}
