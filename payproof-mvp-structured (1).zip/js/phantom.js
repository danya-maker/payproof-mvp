let phantomProvider = null;

function getPhantomProvider(){
  if(window.phantom && window.phantom.solana){
    return window.phantom.solana;
  }

  if(window.solana && window.solana.isPhantom){
    return window.solana;
  }

  return null;
}

function shortAddress(address){
  if(!address) return "";
  return address.slice(0,6) + "..." + address.slice(-6);
}

function setWalletConnected(address){
  const button = document.getElementById("connectWalletBtn");
  const wallet = document.getElementById("walletAddress");

  if(!button || !wallet) return;

  wallet.style.display = "inline-flex";
  wallet.textContent = shortAddress(address);
  button.textContent = "Disconnect";
}

function setWalletDisconnected(){
  const button = document.getElementById("connectWalletBtn");
  const wallet = document.getElementById("walletAddress");

  if(!button || !wallet) return;

  wallet.style.display = "none";
  wallet.textContent = "Not connected";
  button.textContent = "Connect Phantom";
}

async function connectPhantom(){
  phantomProvider = getPhantomProvider();

  if(!phantomProvider){
    const isMobile = /Android|iPhone|iPad|iPod/i.test(navigator.userAgent);

    if(isMobile){
      const phantomBrowseUrl =
        "https://phantom.app/ul/browse/" +
        encodeURIComponent(window.location.href);

      window.location.href = phantomBrowseUrl;
      return;
    }

    window.open(
      "https://phantom.app/download",
      "_blank",
      "noopener,noreferrer"
    );
    toast("Opening Phantom download...");
    return;
  }

  try{
    const response = await phantomProvider.connect();
    const publicKey =
      response?.publicKey ||
      phantomProvider.publicKey;

    if(!publicKey){
      throw new Error("Phantom connected but public key was not returned.");
    }

    const address = publicKey.toString();
    localStorage.setItem("payproof_wallet", address);
    setWalletConnected(address);
    toast("✓ Phantom connected");
  }catch(error){
    console.error("Phantom connection error:", error);

    if(error?.code === 4001){
      toast("Connection cancelled in Phantom.");
    }else{
      toast("Could not connect to Phantom.");
    }
  }
}

async function disconnectPhantom(){
  if(!phantomProvider) return;

  try{
    await phantomProvider.disconnect();
  }catch(error){
    console.error("Phantom disconnect error:", error);
  }

  setWalletDisconnected();
}

function setupPhantom(){
  phantomProvider = getPhantomProvider();

  if(!phantomProvider){
    return;
  }

  if(phantomProvider.isConnected && phantomProvider.publicKey){
    setWalletConnected(phantomProvider.publicKey.toString());
  }

  phantomProvider.on?.("connect", (publicKey) => {
    if(publicKey){
      setWalletConnected(publicKey.toString());
    }
  });

  phantomProvider.on?.("disconnect", () => {
    setWalletDisconnected();
  });

  phantomProvider.on?.("accountChanged", (publicKey) => {
    if(publicKey){
      setWalletConnected(publicKey.toString());
    }else{
      setWalletDisconnected();
    }
  });
}

document.getElementById("connectWalletBtn")?.addEventListener(
  "click",
  async () => {
    phantomProvider = getPhantomProvider();

    if(phantomProvider?.isConnected || phantomProvider?.publicKey){
      await disconnectPhantom();
    }else{
      await connectPhantom();
    }
  }
);

window.addEventListener("load", () => {
  setupPhantom();
  setTimeout(setupPhantom, 300);
  setTimeout(setupPhantom, 1000);
});
