# PayProof

> Every payment. Proven.

PayProof is an MVP that makes salary payments more transparent, structured, and verifiable for employees and small businesses.

**Solana Create 2026 · Colosseum Submission**

[Live Demo](https://payproof-mvp.vercel.app/) · [Solana Explorer](https://explorer.solana.com/?cluster=devnet)

---

## Problem

Salary delays can create misunderstandings and disputes between employees and employers. Payment information is often scattered across messages, bank statements, and personal records, making it difficult to maintain a clear and consistent payment history.

## Solution

PayProof provides a simple payment history where salary payments and delays can be recorded in one place. The MVP can also write a payment event to **Solana Devnet** through the Memo Program, creating a publicly verifiable transaction record.

---

## Why Solana

- **Fast and low-cost** — suitable for recording frequent payment events.
- **Public verification** — Devnet transactions can be checked in Solana Explorer.
- **Wallet-based identity** — Phantom provides a simple way to sign payment records.
- **Composable ecosystem** — the MVP can later integrate with payroll and payment infrastructure.

---

## Features

- Payment history with dates, amounts, and statuses.
- Delay counter and warning logic.
- Phantom wallet connection.
- Payment event recording on Solana Devnet.
- Memo-based transaction metadata.
- Direct Solana Explorer transaction link after confirmation.
- Simple dashboard designed for employees and small businesses.

---

## How It Works

1. Open the PayProof dashboard.
2. Review the employee payment history and delay counter.
3. Connect a Phantom wallet.
4. Enter the payment amount and a comment.
5. Confirm the transaction in Phantom.
6. PayProof writes a payment event to Solana Devnet using the Memo Program.
7. The resulting transaction can be verified in Solana Explorer.

---

## Tech Stack

| Layer | Technology |
| --- | --- |
| Frontend | HTML, CSS, JavaScript |
| Blockchain | Solana Devnet |
| Wallet | Phantom |
| Web3 | `@solana/web3.js` |
| On-chain record | Solana Memo Program |
| Deployment | Vercel |

---

## Architecture

```text
┌─────────────────────┐
│   PayProof Frontend  │
│  HTML / CSS / JS     │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│   Phantom Wallet     │
│   Sign transaction   │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│    Solana Devnet     │
│    Memo Program      │
└──────────┬──────────┘
           │
           ▼
┌─────────────────────┐
│   Solana Explorer    │
│ Public verification  │
└─────────────────────┘
```

The current MVP uses the Solana Memo Program to attach structured payment information to a Devnet transaction. It does **not** move real salary funds on-chain.

---

## Project Structure

```text
payproof-mvp/
├── index.html          # Main MVP application
├── README.md           # Project documentation
├── .gitignore          # Git ignore rules
├── assets/             # Project assets
└── docs/               # Additional project documentation
```

---

## Quick Start

### Requirements

- A modern web browser.
- Phantom wallet for the blockchain demo.
- Solana Devnet enabled in Phantom.
- Test SOL for transaction fees.

### Run locally

This is a static web application, so no backend installation is required.

```bash
git clone https://github.com/YOUR_USERNAME/payproof-mvp.git
cd payproof-mvp
```

Open `index.html` in a browser, or serve the folder with any static web server.

For example:

```bash
python3 -m http.server 8000
```

Then open `http://localhost:8000`.

### Blockchain demo

1. Open the application on a device with Phantom installed.
2. Switch Phantom to Solana Devnet.
3. Click **Connect Phantom**.
4. Enter the payment information.
5. Click the button to record the payment on Solana Devnet.
6. Approve the transaction in Phantom.
7. Open the generated Solana Explorer link to verify the transaction.

---

## MVP Scope

This project is a hackathon MVP and demonstrates the core concept rather than a production payroll system.

Currently:

- Payment history is demonstrated with sample data.
- Delay warnings are represented in the frontend.
- Blockchain records are written to Solana **Devnet**.
- The MVP does not process real salary payments.
- The MVP does not provide legal or financial advice.

---

## Roadmap

- [x] Payment history dashboard
- [x] Delay tracking and warning logic
- [x] Phantom wallet connection
- [x] Solana Devnet payment-event recording
- [x] Solana Explorer verification
- [ ] Employee and employer accounts
- [ ] Two-sided payment confirmation
- [ ] Real payment integrations
- [ ] Analytics and reporting dashboard
- [ ] Production Solana deployment
- [ ] Payroll and accounting integrations

---

## Resources

- **Live Application:** https://payproof-mvp.vercel.app/
- **Solana Devnet Explorer:** https://explorer.solana.com/?cluster=devnet
- **Project Repository:** https://github.com/YOUR_USERNAME/payproof-mvp

---

## License

This project was created as a hackathon MVP for Solana Create 2026.
