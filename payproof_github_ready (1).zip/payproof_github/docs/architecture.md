# PayProof Architecture

PayProof is currently a lightweight static MVP.

```text
User
  │
  ▼
PayProof Web App
  │
  ├── Payment history
  ├── Delay tracking
  └── Payment event form
          │
          ▼
     Phantom Wallet
          │
          ▼
     Solana Devnet
          │
          ▼
     Memo Program
          │
          ▼
   Solana Explorer
```

The application creates a Solana Devnet transaction containing a structured payment event in the Memo Program. The transaction signature is then displayed as an Explorer link.
